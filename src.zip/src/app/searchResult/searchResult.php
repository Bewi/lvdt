<div id="searchResult">
    <div  class="container">
        <div class="row">
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <div class="prices row">
                        <span class="col-lg-5">3,70€ /50gr</span>
                        <span class="col-lg-5">5,70€ /100gr</span>
                    </div>
                    <div class="row">
                        <span class="description col-lg-10">
                        Thé noir de Chine keemun, à la bergamote.  Arôme de bergamote, avec zestes d'orange et pétales de bleuets. 
                        </span>
                    </div>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
        </div>
        <div class="row">
            <ul class="pager">
                <li><a href="#" class="active">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
            </ul>
        </div>
    </div>
</div>