
<div id="big-picture" class="container">
    <img src="./images/home-big-picture.png" alt="" />
</div>
