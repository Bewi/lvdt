<div id="perso">
    <div class="container">
        <h1>Bonjour Michel, bienvenue dans votre espace.</h1> 
        <h3>Fidelité</h3>
        <p><span class="strong">1650grammes</span> de thé acheté cette année. Cela correspond à <span class="strong">3%</span> de reduction sur tous vos prochains achats.</p>
        <h3>Historique</h3>
    </div>
</div>
<div id="history">
    <div class="container">
        <div class="row item">
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                <img class="col-xs-2 col-sm-8 col-md-2 col-lg-2" src="./images/items/the-2.png" />
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <h3>Saint petersbourg</h3>
                    <span>200grammes</span>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 tail">
                    <h3>26/08/2016</h3>
                    <a href="#">Voir la fiche produit</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                <img class="col-xs-2 col-sm-8 col-md-2 col-lg-2" src="./images/items/the-2.png" />
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <h3>Saint petersbourg</h3>
                    <span>200grammes</span>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 tail">
                    <h3>26/08/2016</h3>
                    <a href="#">Voir la fiche produit</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                <img class="col-xs-2 col-sm-8 col-md-2 col-lg-2" src="./images/items/the-2.png" />
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <h3>Saint petersbourg</h3>
                    <span>200grammes</span>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 tail">
                    <h3>26/08/2016</h3>
                    <a href="#">Voir la fiche produit</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                <img class="col-xs-2 col-sm-8 col-md-2 col-lg-2" src="./images/items/the-2.png" />
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <h3>Saint petersbourg</h3>
                    <span>200grammes</span>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 tail">
                    <h3>26/08/2016</h3>
                    <a href="#">Voir la fiche produit</a>
                </div>
            </div>
            <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                <img class="col-xs-2 col-sm-8 col-md-2 col-lg-2" src="./images/items/the-2.png" />
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                    <h3>Saint petersbourg</h3>
                    <span>200grammes</span>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 tail">
                    <h3>26/08/2016</h3>
                    <a href="#">Voir la fiche produit</a>
                </div>
            </div>
        </div>       
    </div>
</div>