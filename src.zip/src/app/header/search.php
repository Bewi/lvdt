<div id="search">
    <div class="container">
        <input type="text" placeholder="Rechercher un arôme, ingrédient ..." />
        <img src="./images/search.svg" alt="" />
    </div>
</div>