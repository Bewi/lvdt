<div id="discover">
    <div class="container">
        <h1>Découvrez d'autres produits</h1>
        <div class="row">
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
            <div class="item col-xs-12 col-sm-2 col-md-2 col-lg-2">
                <img class="thumb" src="./images/items/the-2.png" alt="" />
                <div class="item-details">
                    <h3>Camomille</h3>
                    <a class="details" href="#">Détails <img src="images/detail.svg" /></a>
                </div>
            </div>
        </div>
    </div>
</div>