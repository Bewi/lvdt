<footer>
    <div class="container">
        <div class="col-xs-5 col-sm-5 col-md-3 col-lg-2">
            <h3>Informations</h3>
            <span>contact@le+ventdesthes.com</span>
            <a href="">Mentions légales</a>
            <a href="">CGV</a>
        </div>
        <div class="col-xs-5 col-sm-5 col-md-3 col-lg-2">
            <h3>contact</h3>
            <span>contact@leventdesthes.com</span>
            <span>03 28 66 58 08</span>
            <a href="">Facebook</a>
        </div>
        <div class="col-lg-offset-2 col-xs-5 col-sm-5 col-md-2">
            <h3>adresse</h3>
            <span>02 rue Téhvenet</span>
            <span>59140 Dunkerque</span>
        </div>
        <div class="col-xs-5 col-sm-5 col-md-2">
            <h3>Horaires</h3>
            <span>Du lundi au samedi</span>
            <span>De 9h à 19h</span>
        </div>
    </div>
</footer>